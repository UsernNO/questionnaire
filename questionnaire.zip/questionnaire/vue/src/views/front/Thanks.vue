<template>
    <div class="main-content">
        <div style="min-height: 80vh; display: flex; align-items: center; justify-content: center; flex-direction: column">
            <div style="font-size: 50px; margin-bottom: 30px">感谢你的参与！祝你生活愉快~</div>
            <div> <a href="/front/home" style="font-size: 30px">返回首页</a></div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Thanks"
    }
</script>

<style scoped>

</style>