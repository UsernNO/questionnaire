<template>
    <div class="main-content">
            <div class="card">
                    <div style="text-align: center; padding-bottom: 20px; font-size: 25px;color: #2a60c9; border-bottom: 1px solid #ddd" >{{pages.name}}</div>

                <div style="padding: 10px 0">
                   <div style="margin-bottom: 15px">
                       <div style="margin-bottom: 10px; font-size: 18px" v-for="(item,index) in questionList" :key="item.id">
                           <div><span>{{index + 1}}</span> <span>{{item.name}}</span>
                               <el-tag v-if="item.type === '单选题'" type="primary">单选题</el-tag>
                               <el-tag v-if="item.type === '多选题'" type="success">多选题</el-tag>
                               <el-tag v-if="item.type === '填空题'" type="warning">填空题</el-tag>
                           </div>
                           <div> <!--    遍历内容-->
                               <div v-for="sub in item.questionItemList" :key="sub.id" style="margin-bottom: 5px">
                                  <div v-if="item.type === '单选题'">
                                      <el-radio :label="sub.content"></el-radio>
                                  </div>
                                   <div v-if="item.type === '多选题'">
                                       <el-checkbox :label="sub.content"></el-checkbox>
                                   </div>
                                   <div v-if="item.type === '填空题'">
                                       <el-input type="textarea"></el-input>
                                   </div>
                               </div>
                           </div>
                       </div>

                   </div>
                </div>

                <div style="text-align: center">
                    <el-button size="medium" type="primary" @click="closeWin">关 闭</el-button>
                </div>
            </div>
    </div>
</template>

<script>
    export default {
        name: "Preview",
        data(){
            return{
                pages:{},
                questionList:[],
            }
        },
        created() {
            this.load();
        },
        methods:{
            load(){
                let  pageId = this.$route.query.pageId; //这个方式拿到home传的值
                this.$request.get('/pages/selectById/' + pageId).then(res =>{ //注意Id后面需要添加/否则报错404
                    this.pages = res.data || {}
                })
                this.$request.get('/question/selectByPageId',{
                    params:{
                        pageId : pageId
                    }
                }).then(res =>{
                    this.questionList = res.data || []
                })
            },
            closeWin(){
                window.close();
            }
        }
    }
</script>

<style scoped>

</style>