<template>
    <div class="main-content">
            <div style="display: flex">

                <div style="flex: 1">
                    <el-button icon="" type="primary" size="medium" class="btn-green" @click="handleAdd()">创建新问卷</el-button>
                </div>

                <div>
                    <el-input v-model="name" style="width: 300px;margin-right: 10px" size="medium" placeholder="请输入名称进行问卷搜索" clearable></el-input>
                    <el-button icon="" type="primary" size="medium" @click="load(1)">搜索</el-button>
                </div>
            </div>

        <div class="card" v-for="item in tableData" :key="item.id" style="margin-bottom: 50px;margin-top:15px;height: 150px;border: 1px solid black">
                <div style="display: flex">
                    <div style="flex: 1; width: 0">
<!--                style="display: flex; align-items: center"强行居中        -->
                       <div style="display: flex; align-items: center;margin-bottom: 35px;display: block">
                           <el-tag v-if="item.saved === '否'" type="warning">未发布</el-tag>
                           <el-tag v-if="item.saved === '是'" type="success">已发布</el-tag>
                           <span style="font-size: 20px;text-align: center;margin-left: 10px">{{item.name}}</span>
                       </div>
                            <el-button type="text" style="font-size: 16px" @click="handleEdit(item)"><i class="el-icon-edit"></i>  编辑</el-button>
                            <el-button type="text" style="font-size: 16px" @click="desigin(item.id)"><i class="el-icon-setting"></i>  设计</el-button>
                            <el-button type="text" style="font-size: 16px"><i class="el-icon-document-copy"></i>  复制</el-button>
                            <el-button type="text" style="font-size: 16px"><i class="el-icon-delete"></i>  分析</el-button>
                            <el-button type="text" style="font-size: 16px;color: #ff5700" v-if="item.open === '否'"><i class="el-icon-delete"></i>  删除</el-button>
                            <el-button type="text" style="font-size: 16px; color: orange"><i class="el-icon-s-marketing"></i>  数据统计</el-button>
                        <div>


                        </div>

                    </div>

                    <div style="width: 150px; height: 100px">
                            <img :src="item.img" alt="暂无图片" style="width: 100%;height: 100px;border-radius: 5px;display: block">
                    </div>
                </div>
        </div>

        <div v-if="total">
            <el-pagination
                    background
                    @current-change="handleCurrentChange"
                    :current-page="pageNum"
                    :page-size="pageSize"
                    layout="total, prev, pager, next"
                    :total="total">
            </el-pagination>
        </div>

        <el-dialog title="信息" :visible.sync="fromVisible" width="40%" :close-on-click-modal="false" destroy-on-close>
            <el-form :model="form" label-width="100px" style="padding-right: 50px" :rules="rules" ref="formRef">
                <el-form-item label="模板名称" prop="name">
                    <el-input v-model="form.name" placeholder="模板名称"></el-input>
                </el-form-item>
                <el-form-item label="模板介绍" prop="descr">
                    <el-input v-model="form.descr" placeholder="模板介绍"></el-input>
                </el-form-item>
                <el-form-item label="封面图" prop="img">
                    <el-upload
                            :action="$baseUrl + '/files/upload'"
                            :headers="{ token: user.token }"
                            list-type="picture"
                            :on-success="handleImgSuccess"
                    >
                        <el-button type="primary">上传</el-button>
                    </el-upload>
                </el-form-item>
                <el-form-item label="是否公开" prop="open" v-if="user.role === 'ADMIN' ">
                    <el-radio-group v-model="form.open">
                        <el-radio label="是"></el-radio>
                        <el-radio label="否"></el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="fromVisible = false">取 消</el-button>
                <el-button type="primary" @click="save">确 定</el-button>
            </div>
        </el-dialog>


    </div>
    
</template>

<script>
    export default {
        name: "FPages",
        data(){
            return{
                tableData: [],  // 所有的数据
                pageNum: 1,   // 当前的页码
                pageSize: 5,  // 每页显示的个数
                total: 0,
                name:null,
                fromVisible: false,
                form: {},
                //表单校验
                rules: {
                    name: [
                        {required: true, message: '请输入名称', trigger: 'blur'},
                    ],
                    descr: [
                        {required: true, message: '请输入简介', trigger: 'blur'},
                    ]
                },
                user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
            }
        },
        created() {
            this.load(1)
        },
        methods:{
            desigin(pageId){
                    window.open('/front/design?pageId=' + pageId)
            },
            handleAdd() {   // 新增数据
                this.form = {}  // 新增数据的时候清空数据
                this.fromVisible = true   // 打开弹窗
            },
            handleEdit(row) {   // 编辑数据
                this.form = JSON.parse(JSON.stringify(row))  // 给form对象赋值  注意要深拷贝数据
                this.fromVisible = true   // 打开弹窗
            },
            save() {   // 保存按钮触发的逻辑  它会触发新增或者更新
                this.$refs.formRef.validate((valid) => {
                    if (valid) {
                        this.$request({
                            url: this.form.id ? '/pages/update' : '/pages/add',
                            method: this.form.id ? 'PUT' : 'POST',
                            data: this.form
                        }).then(res => {
                            if (res.code === '200') {  // 表示成功保存
                                this.$message.success('保存成功')
                                this.load(1)
                                this.fromVisible = false
                            } else {
                                this.$message.error(res.msg)  // 弹出错误的信息
                            }
                        })
                    }
                })
            },
           load(pageNum){
              if(pageNum)this.pageNum = pageNum;
              this.$request.get("/pages/selectPage",{
                  params:{
                      pageNum : this.pageNum,
                      pageSize : this.pageSize,
                      name : this.name
                  }
              }).then(res =>{
                  this.tableData = res.data?.list
                  this.total = res.data?.total
              })
           },
            reset() {
                this.name = null
                this.load(1)
            },
            handleCurrentChange(pageNum){
               this.load(pageNum)
            },
            handleImgSuccess(res){
               this.form.img = res.data  //后台返回的url图片赋值给表单
            }
        }
    }
</script>

<style scoped>

</style>